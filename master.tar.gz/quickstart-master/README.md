# Prisma Quickstart

This repository contains the starter templates for the 5min Quickstart in the [Prisma docs](https://www.prisma.io/docs).

- [TypeScript](https://www.prisma.io/docs/getting-started/quickstart-typescript)
- [JavaScript](https://www.prisma.io/docs/getting-started/quickstart-javascript)
